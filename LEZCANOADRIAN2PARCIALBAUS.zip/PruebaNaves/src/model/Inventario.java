package model;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

/**
 *
 * @author adri pc
 * @param <T>
 */
public class Inventario<T extends CSVSerializable> implements Iterable<T> {

    List<T> items = new ArrayList<>();

    public void agregar(T item) {
        if (item == null) {
            throw new IllegalArgumentException("No se admiten null");
        }
        items.add(item);
    }

    public void eliminar(int indice) {
        validarIndice(indice);
        items.remove(indice);
    }

    public int tamanioLista() {
        return items.size();
    }

    private void validarIndice(int indice) {
        if (indice < 0 || indice >= tamanioLista()) {
            throw new IndexOutOfBoundsException("Indice no válido");
        }
    }

    public void listarElementos() {
        if (items.isEmpty()) {
            System.out.println("Lista vacía");
        }
        for (T item : items) {
            System.out.println(item);
        }
    }

    public void ordenar() {
        ordenar((Comparator<? super T>) Comparator.naturalOrder());
    }

    public void ordenar(Comparator<? super T> comparador) {
        items.sort(comparador);
    }

    public List<T> filtrar(Filtrador<? super T> criterio) {
        List<T> toReturn = new ArrayList<>();
        for (T item : items) {

            if (criterio.filtrar(item)) {
                toReturn.add(item);
            }
        }
        return toReturn;
    }

    public List<T> transformar(Function<? super T, ? extends T> transformacion) {
        List<T> toReturn = new ArrayList<>();
        for (T item : items) {
            toReturn.add(transformacion.apply(item));
        }
        return toReturn;
    }

    public void paraCadaElemento(Consumer<? super T> accion) {
        for (T item : items) {
            accion.accept(item);
        }
    }

    @Override
    public Iterator<T> iterator() {
        if (!items.isEmpty() && items.get(0) instanceof Comparable) {
            return iterator((Comparator<? super T>) Comparator.naturalOrder());
        }
        return (new ArrayList<>(items)).iterator();
    }

    public Iterator<T> iterator(Comparator<? super T> comparador) {
        List aux = new ArrayList<>(items);
        aux.sort(comparador);
        return aux.iterator();
    }

    //-----------------------------------CSV-----------------------------------
    public void guardarEnCSV(String path) {
        File archivo = new File(path);

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(archivo))) {
            bw.write("id,titulo,capacidad,categoria\n");
            for (T e : items) {
                if (e instanceof CSVSerializable csv) {
                    bw.write(csv.toCSV() + "\n");
                }
            }

        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    public void cargarDesdeCSV(String path, Function<String, T> transformador) {
        items.clear();
        File archivo = new File(path);

        try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
            String linea;
            br.readLine(); 
            while ((linea = br.readLine()) != null) {
                items.add(transformador.apply(linea)); 
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    // ---------------------------------------binario-------------------------------------------
    public <T> void guardarEnArchivo(String path) {

        if (items == null || items.isEmpty()) {
            System.out.println("No hay elementos para guardar.");
            return;
        }

        try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(path))) {

            salida.writeObject(items);

        } catch (IOException ex) {
            ex.printStackTrace();
            System.out.println(ex.getMessage());
        }
    }

    public void cargarDesdeArchivo(String path) {

        File archivo = new File(path);
        if (!archivo.exists() || archivo.length() == 0) {
            System.out.println("El archivo no existe o está vacío.");
        }

        try (ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(path))) {
            items = (List<T>) entrada.readObject();

        } catch (IOException | ClassNotFoundException ex) {
            System.out.println(ex.getMessage());
        }

    }

}
