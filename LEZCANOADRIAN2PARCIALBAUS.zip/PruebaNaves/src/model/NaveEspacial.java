package model;

/**
 *
 * @author adri pc
 */
public class NaveEspacial implements Comparable<NaveEspacial>, CSVSerializable {

    private static final Long serialVersionUID = 1L;
    private int ID;
    private String nombre;
    private int capacidadTripulacion;
    private Categoria categoria;

    public NaveEspacial(int ID, String nombre, int capacidadTripulacion, Categoria categoria) {
        this.ID = ID;
        this.nombre = nombre;
        this.capacidadTripulacion = capacidadTripulacion;
        this.categoria = categoria;
    }

    public int getCapacidadTripulacion() {
        return capacidadTripulacion;
    }

    public String getNombre() {
        return nombre;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    @Override
    public String toString() {
        return "NaveEspacial{" + "ID=" + ID + ", nombre=" + nombre + ", capacidadTripulacion=" + capacidadTripulacion + ", categoria=" + categoria + '}';
    }

    @Override
    public int compareTo(NaveEspacial n) {
        return Integer.compare(ID, n.ID);
    }

    @Override
    public String toCSV() {
        return ID + "," + nombre + "," + capacidadTripulacion + "," + categoria;
    }

    public int getID() {
        return ID;
    }
    

    
    
    public void aumentarCapacidad(int aumento) {
        capacidadTripulacion = capacidadTripulacion + aumento;

    }

    public static NaveEspacial fromCSV(String naveCSV) {
        NaveEspacial toReturn = null;
        String[] values = naveCSV.split(",");
        if (values.length == 4) {
            int ID = Integer.parseInt(values[0]);
            String nombre = values[1];
            int CapacidadTripulacion = Integer.parseInt(values[2]);
            Categoria categoria = Categoria.valueOf(values[3]);
            toReturn = new NaveEspacial(ID, nombre, CapacidadTripulacion, categoria);
        }
        return toReturn;
    }

}
