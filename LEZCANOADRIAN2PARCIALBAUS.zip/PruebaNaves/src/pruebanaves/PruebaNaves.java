/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pruebanaves;

import static config.AppConstants.PATH_CSV;
import static config.AppConstants.PATH_SERIAL;
import java.util.List;
import model.Categoria;
import model.Inventario;
import model.NaveEspacial;

public class PruebaNaves {

    public static void main(String[] args) {

        // Crear un inventario de naves espaciales
        Inventario<NaveEspacial> inventarioNaves = new Inventario<>();
        inventarioNaves.agregar(new NaveEspacial(1, "USS Enterprise", 50, Categoria.CIENTIFICA));
        inventarioNaves.agregar(new NaveEspacial(2, "Millennium Falcon", 3, Categoria.TRANSPORTE));
        inventarioNaves.agregar(new NaveEspacial(3, "TIE Fighter", 1, Categoria.MILITAR));
        inventarioNaves.agregar(new NaveEspacial(4, "X-Wing", 2, Categoria.MILITAR));
        inventarioNaves.agregar(new NaveEspacial(5, "Discovery One", 100, Categoria.CIENTIFICA));
        inventarioNaves.agregar(new NaveEspacial(6, "Falcon", 20, Categoria.TRANSPORTE));

        // Mostrar todas las naves en el inventario
        System.out.println("Inventario de naves espaciales:");
        inventarioNaves.paraCadaElemento(nave -> System.out.println(nave));

        linea();

        // Filtrar naves por categoría MILITAR
        System.out.println("\nNaves de la categoria MILITAR:");
        inventarioNaves.filtrar((NaveEspacial n) -> n.getCategoria().equals(Categoria.MILITAR)).forEach(nave -> System.out.println(nave));

        linea();

        // Filtrar naves cuyo nombre contiene "Falcon"
        System.out.println("\nNaves cuyo nombre contiene 'Falcon':");
        inventarioNaves.filtrar((NaveEspacial n) -> n.getNombre().equals("Falcon")).forEach(nave -> System.out.println(nave));

        linea();

        // Ordenar naves de manera natural (por id)
        System.out.println("\nNaves ordenadas de manera natural (por ID):");
        inventarioNaves.ordenar();
        inventarioNaves.paraCadaElemento(nave -> System.out.println(nave));

        linea();
        // Ordenar naves por nombre utilizando un Comparator 
        System.out.println("\nNaves ordenadas por nombre:");
        inventarioNaves.ordenar((n1, n2) -> n1.getNombre().compareTo(n2.getNombre()));
        inventarioNaves.paraCadaElemento(nave -> System.out.println(nave));
        
        linea();
        // Guardar el inventario en un archivo binario
        inventarioNaves.guardarEnArchivo(PATH_SERIAL);

        // Cargar el inventario desde el archivo binario
        Inventario<NaveEspacial> inventarioCargado = new Inventario<>();
        inventarioCargado.cargarDesdeArchivo(PATH_SERIAL);
        System.out.println("\nNaves cargadas desde archivo binario:");
        inventarioCargado.paraCadaElemento(nave -> System.out.println(nave));

        // Guardar el inventario en un archivo CSV
        inventarioNaves.guardarEnCSV(PATH_CSV);
        linea();
        // Cargar el inventario desde el archivo CSV
        inventarioCargado.cargarDesdeCSV(PATH_CSV, linea -> NaveEspacial.fromCSV(linea));
        System.out.println("\nNaves cargadas desde archivo CSV:");
        inventarioCargado.paraCadaElemento(nave -> System.out.println(nave));

    }

    public static void linea() {
        System.out.println("----------------------------------------------------------");
    }
}
